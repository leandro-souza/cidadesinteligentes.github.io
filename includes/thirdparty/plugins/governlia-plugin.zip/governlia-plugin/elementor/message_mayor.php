<?php

namespace GOVERNLIAPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Message_Mayor extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'governlia_message_mayor';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Message Mayor', 'governlia' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-briefcase';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'governlia' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'message_mayor',
			[
				'label' => esc_html__( 'Message Mayor', 'governlia' ),
			]
		);
		$this->add_control(
			'feature_img',
			[
				'label' => __( 'Feature Image', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'big_title',
			[
				'label'       => __( 'BIG Transparent Title', 'governlia' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your BIG Transparent Title', 'governlia' ),
				'default'     => __( 'Governlia', 'governlia' ),
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'governlia' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'governlia' ),
				'default'     => __( 'City With Equity - Efficiency - Opportunity', 'governlia' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'governlia' ),
			]
		);
		$this->add_control(
			'sub_heading',
			[
				'label'       => __( 'Sub Heading', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Heading', 'governlia' ),
			]
		);
		$this->add_control(
			'history_year',
			[
				'label'       => __( 'Year Of History', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Year Of History', 'governlia' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Description', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'governlia' ),
			]
		);
		$this->add_control(
			'signature_img',
			[
				'label' => __( 'Signature Image', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'author_designation',
			[
				'label'       => __( 'Author Designation', 'governlia' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Author Designation', 'governlia' ),
			]
		);
		$this->add_control(
              'funfact', 
			  	[
            		'type' => Controls_Manager::REPEATER,
            		'seperator' => 'before',
            		'default' => 
						[
                			['block_title' => esc_html__('Years Of Experience', 'governlia')],
                			['block_title' => esc_html__('programs for the city', 'governlia')],
                			['block_title' => esc_html__('Approved covid-19 centers', 'governlia')]
						],
            		'fields' => 
						[
							[
                    			'name' => 'block_title',
                    			'label' => esc_html__('Title', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXTAREA,
                    			'default' => esc_html__('', 'governlia')
                			],
							[
                    			'name' => 'counter_start',
                    			'label' => esc_html__('Count Start Value', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXT,
								'default' => esc_html__('', 'governlia')
                			],
							[
                    			'name' => 'counter_stop',
                    			'label' => esc_html__('Count Stop Value', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXT,
								'default' => esc_html__('', 'governlia')
                			],
						],
            	    'title_field' => '{{block_title}}',
                 ]
        );
		$this->end_controls_section();
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
        
        <!-- Mayor Message section -->
        <section class="mayor-message-section">
            <div class="auto-container">
                <div class="row">
                    <?php if($settings['feature_img']['id']){ ?>
                    <div class="col-lg-5">
                        <div class="image"><img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_img']['id']));?>" alt=""></div>
                    </div>
                    <?php } ?>
                    <div class="col-lg-7">
                        <div class="content-block pl-lg-5">
                            <?php if($settings['big_title'] || $settings['subtitle'] || $settings['title']) { ?>
                            <div class="sec-title">
                                <?php if($settings['big_title']) { ?><div class="big-title"><?php echo wp_kses($settings['big_title'], true);?></div><?php } ?>
								<?php if($settings['subtitle']) { ?><div class="sub-title"><?php echo wp_kses($settings['subtitle'], true);?></div><?php } ?>
                                <?php if($settings['title']) { ?><h2><?php echo wp_kses($settings['title'], true);?></h2><?php } ?>
                            </div>
                            <?php } ?>
                            <div class="row">
                                <div class="col-lg-8">
                                    <?php if($settings['sub_heading']) { ?><h3><?php echo wp_kses($settings['sub_heading'], true);?></h3><?php } ?>
                                    <?php if($settings['history_year']) { ?><h4><?php echo wp_kses($settings['history_year'], true);?></h4><?php } ?>
                                    <?php if($settings['text']) { ?>
                                    <div class="text">
                                        <?php echo wp_kses($settings['text'], true);?>
                                    </div>
                                    <?php } ?>
									<?php if($settings['signature_img']['id']){ ?><div class="sign"><img src="<?php echo esc_url(wp_get_attachment_url($settings['signature_img']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'governlia')?>"></div><?php } ?>
                                    <?php if($settings['author_designation']) { ?><div class="designation"><?php echo wp_kses($settings['author_designation'], true);?></div><?php } ?>
                                </div>
                                <div class="col-lg-4">
                                    <div class="funfacts">
                                        <?php foreach($settings['funfact'] as $key => $item):?>
                                        <div class="column counter-column">
                                            <div class="inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                                <div class="content">
                                                    <div class="text"><?php echo wp_kses($item['block_title'], true); ?></div>
                                                    <div class="count-outer count-box">
                                                        <span class="count-text" data-speed="3000" data-stop="<?php echo wp_kses($item['counter_stop'], true); ?>"><?php echo wp_kses($item['counter_start'], true); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach;?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
		<?php 
	}

}
