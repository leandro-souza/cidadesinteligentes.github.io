<?php

namespace GOVERNLIAPLUGIN\Element;


class Elementor {
	static $widgets = array(
		//Home Page One
		'slider_v1',
		'about_us',
		'funfacts',
		'programs_initiatives',
		'message_mayor',
		'our_projects',
		'our_service_v1',
		'our_departments',
		'upcoming_events',
		'video_section',
		'our_testimonials',
		'our_suggestions',
		'latest_news',
		'our_clients',
		//Home Page Two
		'slider_v2',
		'feature_services',
		'about_us_v2',
		'feature_services_v2',
		'our_services_v2',
		'municipal_services',
		'upcoming_events_v2',
		'quick_services',
		'our_team',
		'latest_news_v2',
		//Inner Pages
		'call_to_action',
		'our_service_v3',
		'our_projects_v2',
		'have_a_question',
		'service_single',
		'upcoming_events_v3',
		'blog_grid_view',
		'contact_form',
		'contact_info',
		
		
	);

	static function init() {
		add_action( 'elementor/init', array( __CLASS__, 'loader' ) );
		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_cats' ) );
	}

	static function loader() {

		foreach ( self::$widgets as $widget ) {

			$file = GOVERNLIAPLUGIN_PLUGIN_PATH . '/elementor/' . $widget . '.php';
			if ( file_exists( $file ) ) {
				require_once $file;
			}

			add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'register' ) );
		}
	}

	static function register( $elemntor ) {
		foreach ( self::$widgets as $widget ) {
			$class = '\\GOVERNLIAPLUGIN\\Element\\' . ucwords( $widget );

			if ( class_exists( $class ) ) {
				$elemntor->register_widget_type( new $class );
			}
		}
	}

	static function register_cats( $elements_manager ) {

		$elements_manager->add_category(
			'governlia',
			[
				'title' => esc_html__( 'Governlia', 'governlia' ),
				'icon'  => 'fa fa-plug',
			]
		);
		$elements_manager->add_category(
			'templatepath',
			[
				'title' => esc_html__( 'Template Path', 'governlia' ),
				'icon'  => 'fa fa-plug',
			]
		);

	}
}

Elementor::init();