<?php

namespace GOVERNLIAPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Feature_Services_V2 extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'governlia_feature_services_v2';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Feature Services V2', 'governlia' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-briefcase';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'governlia' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'feature_services_v2',
			[
				'label' => esc_html__( 'Feature Services V2', 'governlia' ),
			]
		);
		$this->add_control(
			'bg_img',
			[
				'label' => __( 'Background Image', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
              'features', 
			  	[
            		'type' => Controls_Manager::REPEATER,
            		'seperator' => 'before',
            		'default' => 
						[
                			['block_title' => esc_html__('Recycle & Garbage', 'governlia')],
                			['block_title' => esc_html__('Food & Drink Hotels', 'governlia')],
                			['block_title' => esc_html__('Get Events Schedule', 'governlia')],
							['block_title' => esc_html__('Travel & Tourism Info', 'governlia')]
						],
            		'fields' => 
						[
							[
                    			'name' => 'icons',
                    			'label' => esc_html__('Enter The icons', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::SELECT2,
                    			'options'  => get_fontawesome_icons(),
                			],
							[
                    			'name' => 'block_title',
                    			'label' => esc_html__('Title', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXT,
                    			'default' => esc_html__('', 'governlia')
                			],
							[
                    			'name' => 'block_text',
                    			'label' => esc_html__('Description', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXT,
                    			'default' => esc_html__('', 'governlia')
                			],
							[
								'name' => 'link',
								'label' => __( 'External Url', 'governlia' ),
								'type' => Controls_Manager::URL,
								'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
								'show_external' => true,
								'default' => ['url' => '','is_external' => true,'nofollow' => true,],
							],
            			],
            	    'title_field' => '{{block_title}}',
                 ]
        );
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'governlia' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Description', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'governlia' ),
			]
		);
		$this->add_control(
			'btn_title',
			[
				'label'       => __( 'Button Title', 'governlia' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Button Title', 'governlia' ),
				'default'     => __( 'Virtual tour', 'governlia' ),
			]
		);
		$this->add_control(
			'btn_link',
				[
				  'label' => __( 'Button Url', 'governlia' ),
				  'type' => Controls_Manager::URL,
				  'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				  'show_external' => true,
				  'default' => [
				    'url' => '',
				    'is_external' => true,
				    'nofollow' => true,
				  ],
			  ]
		);
		$this->add_control(
			'feature_img',
			[
				'label' => __( 'Feature Image', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>
        
        <!-- Features section two -->
        <section class="features-section-two" <?php if($settings['bg_img']['id']){ ?>style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_img']['id']));?>);"<?php } ?>>
            <div class="top-content">
                <div class="auto-container">
                    <div class="row">
                        <?php foreach($settings['features'] as $key => $item):?>
                        <div class="col-lg-3 col-md-6 feature-block-two">
                            <div class="inner-box">
                                <div class="content">
                                    <div class="icon"><span class="<?php echo wp_kses(str_replace( "icon ",  "",  $item['icons']), true); ?>"></span></div>
                                    <h4><?php echo wp_kses($item['block_title'], true); ?></h4>
                                    <div class="link"><a href="<?php echo esc_url($item['link']['url']); ?>"><i class="icon-arrow"></i></a></div>
                                </div>
                                <div class="overlay">
                                    <div class="icon"><span class="<?php echo wp_kses(str_replace( "icon ",  "",  $item['icons']), true); ?>"></span></div>
                                    <h4><?php echo wp_kses($item['block_title'], true); ?></h4>
                                    <h5><?php echo wp_kses($item['block_text'], true); ?></h5>
                                    <div class="link"><a href="<?php echo esc_url($item['link']['url']); ?>"><i class="icon-arrow"></i></a></div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach;?>
                    </div>
                </div>
            </div>
            <div class="bottom-content">
                <div class="row">
                    <div class="col-xl-4">
                        <div class="sec-title style-two light">
                            <h2><?php echo wp_kses($settings['title'], true); ?></h2>                        
                        </div>
                    </div>
                    <div class="col-xl-4">
                        <div class="text">
                            <?php echo wp_kses($settings['text'], true); ?>
                        </div>
                        <div class="link-box">
                            <a href="<?php echo esc_url($settings['btn_link']['url']); ?>" class="theme-btn btn-style-one style-four"><span><?php echo wp_kses($settings['btn_title'], true); ?></span></a>
                        </div>
                    </div>
                    <?php if($settings['feature_img']['id']){ ?>
                    <div class="col-xl-4">
                        <div class="image"><img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_img']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'governlia'); ?>"></div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </section>
                
		<?php 
	}

}
