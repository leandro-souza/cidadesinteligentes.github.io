<?php

namespace GOVERNLIAPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class About_Us extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'governlia_about_us';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'About Us', 'governlia' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-briefcase';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'governlia' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'about_us',
			[
				'label' => esc_html__( 'About Us', 'governlia' ),
			]
		);
		$this->add_control(
			'big_title',
			[
				'label'       => __( 'BIG Transparent Title', 'governlia' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your BIG Transparent Title', 'governlia' ),
				'default'     => __( 'Governlia', 'governlia' ),
			]
		);
		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Sub Title', 'governlia' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Title', 'governlia' ),
				'default'     => __( 'City With Equity - Efficiency - Opportunity', 'governlia' ),
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'governlia' ),
			]
		);
		$this->add_control(
			'sub_heading',
			[
				'label'       => __( 'Sub Heading', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Heading', 'governlia' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Description', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'governlia' ),
			]
		);
		$this->add_control(
			'features_list',
			[
				'label'       => __( 'Feature List', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feature List', 'governlia' ),
			]
		);
		$this->add_control(
			'info_text',
			[
				'label'       => __( 'Contact Info Text', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Contact Info Text', 'governlia' ),
			]
		);
		$this->add_control(
              'contact_info', 
			  	[
            		'type' => Controls_Manager::REPEATER,
            		'separator' => 'before',
            		'default' => 
						[
                			['info_link' => esc_html__('tel:+1(345)20678', 'governlia')],
                			['info_link' => esc_html__('mailto:info@example.com', 'governlia')],
                			['info_link' => esc_html__('#', 'governlia')]
						],
            		'fields' => 
						[
							[
                    			'name' => 'icons',
                    			'label' => esc_html__('Enter The icons', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::SELECT2,
                    			'options'  => get_fontawesome_icons(),
                			],
							[
                    			'name' => 'info_link',
                    			'label' => __( 'External Url', 'governlia' ),
								'type' => Controls_Manager::URL,
								'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
								'show_external' => true,
								'default' => ['url' => '','is_external' => true,'nofollow' => true,],
                			],
            			],
            	    'title_field' => '{{info_link}}',
                 ]
        );
		$this->add_control(
			'about_img_v1',
			[
				'label' => __( 'About Image V1', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'about_img_v2',
			[
				'label' => __( 'About Image V2', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'about_img_v3',
			[
				'label' => __( 'About Image V3', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'style_two',
			[
				'label'   => esc_html__( 'Choose Different Space Style', 'governlia' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'one',
				'options' => array(
					'one' => esc_html__( 'Disable Bottom Space', 'governlia' ),
					'two' => esc_html__( 'Enable Bottom Space ', 'governlia' ),
				),
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
        
        <!-- About section -->
        <section class="about-section <?php if($settings['style_two'] == 'two') echo 'style-two'; else echo ''; ?>">
            <div class="auto-container">
                <?php if($settings['big_title'] || $settings['subtitle'] || $settings['title']) { ?>
                <div class="sec-title text-center">
                    <?php if($settings['big_title']) { ?><div class="big-title"><?php echo wp_kses($settings['big_title'], true);?></div><?php } ?>
                    <?php if($settings['subtitle']) { ?><div class="sub-title"><?php echo wp_kses($settings['subtitle'], true);?></div><?php } ?>
                    <?php if($settings['title']) { ?><h2><?php echo wp_kses($settings['title'], true);?></h2><?php } ?>
                </div>
                <?php } ?>
                <div class="row">
                    <div class="col-lg-5">
                        <div class="content-block wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <h3><?php echo wp_kses($settings['sub_heading'], true);?></h3>
                            <div class="text"><?php echo wp_kses($settings['text'], true);?> </div>
                            
							<?php $features_list = $settings['features_list'];
								if(!empty($features_list)){
								$features_list = explode("\n", ($features_list)); 
							?>
                            <ul class="list">
                                <?php foreach($features_list as $features): ?>
                                <li><?php echo wp_kses($features, true); ?></li>
                                <?php endforeach; ?>
                            </ul>
                            <?php } ?>
                            
                            <div class="bottom-content">
                                <div class="text"><?php echo wp_kses($settings['info_text'], true);?></div>
                                <ul class="contact-link">
                                    <?php foreach($settings['contact_info'] as $key => $item): ?>
                                    <li><a href="<?php echo esc_url($item['info_link']['url']); ?>"><i class="<?php echo wp_kses(str_replace( "icon ",  "",  $item['icons']), true); ?>"></i></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="image-block wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="row">
                                <?php if($settings['about_img_v1']['id'] || $settings['about_img_v2']['id']){ ?>
                                <div class="col-lg-6 column">
                                    <?php if($settings['about_img_v1']['id']){ ?><div class="image"><img src="<?php echo esc_url(wp_get_attachment_url($settings['about_img_v1']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'governlia'); ?>"></div><?php } ?>
                                    <?php if($settings['about_img_v2']['id']){ ?><div class="image"><img src="<?php echo esc_url(wp_get_attachment_url($settings['about_img_v2']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'governlia'); ?>"></div><?php } ?>
                                </div>
                                <?php } ?>
                                
                                <?php if($settings['about_img_v3']['id']){ ?>
                                <div class="col-sm-6 column">
                                    <div class="image"><img src="<?php echo esc_url(wp_get_attachment_url($settings['about_img_v3']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'governlia'); ?>"></div>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
                
		<?php 
	}

}
