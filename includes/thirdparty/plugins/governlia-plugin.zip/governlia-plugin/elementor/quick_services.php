<?php

namespace GOVERNLIAPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Quick_Services extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'governlia_quick_services';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Quick Services', 'governlia' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-briefcase';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'governlia' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'quick_services',
			[
				'label' => esc_html__( 'Quick Services', 'governlia' ),
			]
		);
		$this->add_control(
			'bg_img',
			[
				'label' => __( 'Background Image', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title', 'governlia' ),
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Text', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Text', 'governlia' ),
			]
		);
		$this->add_control(
			'features_list',
			[
				'label'       => __( 'Feature List V1', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feature List V1', 'governlia' ),
			]
		);
		$this->add_control(
			'features_list2',
			[
				'label'       => __( 'Feature List V2', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feature List V2', 'governlia' ),
			]
		);
		$this->add_control(
			'icon_img',
			[
				'label' => __( 'Icon Image', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
              'funfact', 
			  	[
            		'type' => Controls_Manager::REPEATER,
            		'seperator' => 'before',
            		'default' => 
						[
                			['block_title' => esc_html__('Area Covered', 'governlia')],
                			['block_title' => esc_html__('Peoples Lived', 'governlia')],
                			['block_title' => esc_html__('Languages Spoken', 'governlia')]
						],
            		'fields' => 
						[
							[
                    			'name' => 'icons',
                    			'label' => esc_html__('Enter The icons', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::SELECT2,
                    			'options'  => get_fontawesome_icons(),
                			],
							[
                    			'name' => 'counter_start',
                    			'label' => esc_html__('Count Start Value', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXT,
								'default' => esc_html__('', 'governlia')
                			],
							[
                    			'name' => 'counter_stop',
                    			'label' => esc_html__('Count Stop Value', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXT,
								'default' => esc_html__('', 'governlia')
                			],
							[
                    			'name' => 'alphabet_letter',
                    			'label' => esc_html__('Alphabet Letters', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXT,
								'default' => esc_html__('', 'governlia')
                			],
							[
                    			'name' => 'block_title',
                    			'label' => esc_html__('Title', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXT,
                    			'default' => esc_html__('', 'governlia')
                			],
            			],
            	    'title_field' => '{{block_title}}',
                 ]
        );
		$this->end_controls_section();
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$allowed_tags = wp_kses_allowed_html('post');
		?>
        
        <!-- Services section three -->
        <section class="services-section-three" <?php if($settings['bg_img']['id']){ ?>style="background-image: url(<?php echo esc_url(wp_get_attachment_url($settings['bg_img']['id']));?>);"<?php } ?>>
            <div class="auto-container">
                <div class="row align-items-center">
                    <div class="col-xl-8">
                        <div class="content-block">
                            <?php if($settings['title']) { ?>
                            <div class="sec-title style-two mb-30">
                                <h2><?php echo wp_kses($settings['title'], true); ?></h2>
                            </div>
                            <?php } ?>
                            <?php if($settings['text']) { ?><div class="text"><?php echo wp_kses($settings['text'], true); ?></div><?php } ?>
                            
                            <div class="row">
                                <?php $features_list = $settings['features_list'];
									if(!empty($features_list)){
									$features_list = explode("\n", ($features_list)); 
								?>
                                <div class="col-md-6 col-lg-6 col-sm-6">
                                    <ul class="list">
                                        <?php foreach($features_list as $features): ?>
                                        <li><?php echo wp_kses($features, true); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                <?php } ?>
                                <?php $features_list2 = $settings['features_list2'];
									if(!empty($features_list2)){
									$features_list2 = explode("\n", ($features_list2)); 
								?>
                                <div class="col-md-6 col-lg-6 col-sm-6">
                                    <ul class="list">
                                        <?php foreach($features_list2 as $features2): ?>
                                        <li><?php echo wp_kses($features2, true); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                <?php } ?>
                            </div>
                            <?php if($settings['icon_img']['id']){ ?><div class="icon"><img src="<?php echo esc_url(wp_get_attachment_url($settings['icon_img']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'governlia'); ?>"></div><?php } ?>
                        </div>
                    </div>
                    <div class="col-xl-4">
                        <div class="ourfacts">
                            <?php foreach($settings['funfact'] as $key => $item):?>
                            <!--Column-->
                            <div class="column counter-column">
                                <div class="inner wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                                    <div class="icon-outer">
                                        <div class="icon"><span class="<?php echo wp_kses(str_replace( "icon ",  "",  $item['icons']), true); ?>"></span></div>
                                    </div>
                                    <div class="content">
                                        <div class="text"><?php echo wp_kses($item['block_title'], true); ?></div>
                                        <div class="count-outer count-box">
                                            <span class="count-text" data-speed="3000" data-stop="<?php echo wp_kses($item['counter_stop'], true); ?>"><?php echo wp_kses($item['counter_start'], true); ?></span><span><?php echo wp_kses($item['alphabet_letter'], true); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach;?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
		<?php 
	}

}
