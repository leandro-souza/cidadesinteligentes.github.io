<?php

namespace GOVERNLIAPLUGIN\Element;

use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Border;
use Elementor\Repeater;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Plugin;

/**
 * Elementor button widget.
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class Service_Single extends Widget_Base {

	/**
	 * Get widget name.
	 * Retrieve button widget name.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'governlia_service_single';
	}

	/**
	 * Get widget title.
	 * Retrieve button widget title.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Service Single', 'governlia' );
	}

	/**
	 * Get widget icon.
	 * Retrieve button widget icon.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-briefcase';
	}

	/**
	 * Get widget categories.
	 * Retrieve the list of categories the button widget belongs to.
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since  2.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'governlia' ];
	}
	
	/**
	 * Register button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'service_single',
			[
				'label' => esc_html__( 'Service Single', 'governlia' ),
			]
		);
		$this->add_control(
			'sidebar_slug',
			[
				'label'   => esc_html__( 'Choose Sidebar', 'governlia' ),
				'label_block' => true,
				'type'    => Controls_Manager::SELECT,
				'default' => 'Choose Sidebar',
				'options'  => governlia_get_sidebars(),
			]
		);
		$this->add_control(
			'feature_img',
			[
				'label' => __( 'Service Single Image', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'text',
			[
				'label'       => __( 'Description', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Description', 'governlia' ),
			]
		);
		$this->add_control(
			'feature_img_v2',
			[
				'label' => __( 'Feature Image', 'governlia' ),
				'type' => Controls_Manager::MEDIA,
				'default' => ['url' => Utils::get_placeholder_image_src(),],
			]
		);
		$this->add_control(
			'sub_heading',
			[
				'label'       => __( 'Sub Heading', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Sub Heading', 'governlia' ),
			]
		);
		$this->add_control(
			'features_list',
			[
				'label'       => __( 'Feature List', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Feature List', 'governlia' ),
			]
		);
		$this->add_control(
              'features', 
			  	[
            		'type' => Controls_Manager::REPEATER,
            		'separator' => 'before',
            		'default' => 
						[
                			['subtitle1' => esc_html__('Transportation', 'governlia')],
                			['subtitle1' => esc_html__('Wildlife Animals', 'governlia')],
                			['subtitle1' => esc_html__('Utility Services', 'governlia')],
							['subtitle1' => esc_html__('Municipal Court', 'governlia')]
						],
            		'fields' => 
						[
							[
                    			'name' => 'icons',
                    			'label' => esc_html__('Enter The icons', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::SELECT2,
                    			'options'  => get_fontawesome_icons(),
                			],
							[
                    			'name' => 'subtitle1',
                    			'label' => esc_html__('SubTitle', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXT,
                    			'default' => esc_html__('', 'governlia')
                			],
							[
                    			'name' => 'block_title',
                    			'label' => esc_html__('Title', 'governlia'),
								'label_block' => true,
                    			'type' => Controls_Manager::TEXTAREA,
                    			'default' => esc_html__('', 'governlia')
                			],
							[
								'name' => 'link',
								'label' => __( 'External Url', 'governlia' ),
								'type' => Controls_Manager::URL,
								'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
								'show_external' => true,
								'default' => ['url' => '','is_external' => true,'nofollow' => true,],
							],
            			],
            	    'title_field' => '{{subtitle1}}',
                 ]
        );
		$this->add_control(
			'text2',
			[
				'label'       => __( 'Bottom Description', 'governlia' ),
				'type'        => Controls_Manager::TEXTAREA,
				'dynamic'     => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Bottom Description', 'governlia' ),
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since  1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
        
        <!-- Sidebar Page Container -->
        <section class="sidebar-page-container">
            <div class="auto-container">
                <div class="row">
                    <div class="<?php if ( is_active_sidebar( $settings['sidebar_slug'] ) ) echo 'col-lg-8 order-lg-2'; else echo 'col-lg-12'; ?>">
                        <div class="depertment-details pl-5">
                            <?php if($settings['feature_img']['id']){ ?><div class="image mb-30"><img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_img']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'governlia'); ?>"></div><?php } ?>
                            <?php if($settings['text']){ ?>
                            <div class="text mb-40">
                                <?php echo wp_kses($settings['text'], true);?>
                            </div>
                            <?php } ?>
                            <div class="row mb-30">
                                <?php if($settings['feature_img_v2']['id']){ ?>
                                <div class="col-md-6">
                                    <div class="image"><img src="<?php echo esc_url(wp_get_attachment_url($settings['feature_img_v2']['id']));?>" alt="<?php esc_attr_e('Awesome Image', 'governlia'); ?>"></div>
                                </div>
                                <?php } ?>
                                <div class="col-md-6">
                                    <div class="group-title"><h4><?php echo wp_kses($settings['sub_heading'], true);?></h4></div>
                                    <?php $features_list = $settings['features_list'];
										if(!empty($features_list)){
										$features_list = explode("\n", ($features_list)); 
									?>
                                    <ul class="list">
                                        <?php foreach($features_list as $features): ?>
                                        <li><?php echo wp_kses($features, true); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                    <?php } ?>
                                </div>
                            </div>
                            <div class="row">
                                <?php foreach($settings['features'] as $key => $item): ?>
                                <div class="col-md-6 feature-block">
                                    <div class="inner-box">
                                        <div class="icon"><span class="<?php echo wp_kses(str_replace( "icon ",  "", $item['icons']), true);?>"></span></div>
                                        <div class="content">
                                            <div class="category"><a href="<?php echo esc_url($item['link']['url']);?>"><?php echo wp_kses($item['subtitle1'], true);?></a></div>
                                            <h3><?php echo wp_kses($item['block_title'], true);?></h3>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <?php if($settings['text2']){ ?>
                            <div class="text">
                                <?php echo wp_kses($settings['text2'], true);?>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                    <?php if ( is_active_sidebar( $settings['sidebar_slug'] ) ) : ?>
                    <div class="col-lg-4">
                        <aside class="sidebar sidebar-style-two">
                            <?php dynamic_sidebar( $settings['sidebar_slug'] ); ?>
                        </aside>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
                        
		<?php 
	}

}
