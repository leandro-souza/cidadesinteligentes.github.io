<?php
return array(
	'title'      => 'Governlia Project Setting',
	'id'         => 'governlia_meta_projects',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'project' ),
	'sections'   => array(
		array(
			'id'     => 'governlia_projects_meta_setting',
			'fields' => array(
				array(
					'id'    => 'project_url',
					'type'  => 'text',
					'title' => esc_html__( 'Enter Read More Link', 'governlia' ),
				),
			),
		),
	),
);