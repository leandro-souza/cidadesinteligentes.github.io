<?php
if ( ! function_exists( "governlia_add_metaboxes" ) ) {
	function governlia_add_metaboxes( $metaboxes ) {
		$directories_array = array(
			'page.php',
			'projects.php',
			'service.php',
			'team.php',
			'testimonials.php',
		);
		foreach ( $directories_array as $dir ) {
			$metaboxes[] = require_once( GOVERNLIAPLUGIN_PLUGIN_PATH . '/metabox/' . $dir );
		}

		return $metaboxes;
	}

	add_action( "redux/metaboxes/governlia_options/boxes", "governlia_add_metaboxes" );
}

