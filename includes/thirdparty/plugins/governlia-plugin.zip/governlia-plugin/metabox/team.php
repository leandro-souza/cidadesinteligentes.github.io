<?php
return array(
	'title'      => 'Governlia Team Setting',
	'id'         => 'governlia_meta_team',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'team' ),
	'sections'   => array(
		array(
			'id'     => 'governlia_team_meta_setting',
			'fields' => array(
				array(
					'id'    => 'designation',
					'type'  => 'text',
					'title' => esc_html__( 'Designation', 'governlia' ),
				),
				array(
					'id'    => 'team_phone',
					'type'  => 'text',
					'title' => esc_html__( 'Phone Number', 'governlia' ),
				),
				array(
					'id'    => 'team_email',
					'type'  => 'text',
					'title' => esc_html__( 'Email Address', 'governlia' ),
				),
				array(
					'id'    => 'team_url',
					'type'  => 'text',
					'title' => esc_html__( 'Website Link', 'governlia' ),
				),
				array(
					'id'    => 'social_profile',
					'type'  => 'social_media',
					'title' => esc_html__( 'Social Profiles', 'governlia' ),
				),
			),
		),
	),
);