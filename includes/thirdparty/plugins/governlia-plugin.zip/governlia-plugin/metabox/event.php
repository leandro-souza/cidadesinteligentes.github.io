<?php
return array(
	'title'      => 'Governlia Evant Setting',
	'id'         => 'governlia_meta_event',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'tribe_events' ),
	'sections'   => array(
		array(
			'id'     => 'governlia_event_meta_setting',
			'fields' => array(
				
				
			),
		),
	),
);