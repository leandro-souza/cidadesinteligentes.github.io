<?php
///----Blog widgets---
//Popular Posts
class Governlia_Popular_Posts extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Governlia_Popular_Posts', /* Name */esc_html__('Governlia Popular Posts','governlia'), array( 'description' => esc_html__('Show the Popular Posts', 'governlia' )) );
	}
 

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        <!--Popular Posts-->
        <div class="widget_popular_post">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
			
            <?php $query_string = 'posts_per_page='.$instance['number'];
                if( $instance['cat'] ) $query_string .= '&cat='.$instance['cat'];
                 $this->posts($query_string);
            ?>
        </div>
        
		<?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ( $instance ) ? esc_attr($instance['title']) : esc_html__('Popular Posts', 'governlia');
		$number = ( $instance ) ? esc_attr($instance['number']) : 3;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
			
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title: ', 'governlia'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('No. of Posts:', 'governlia'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('categories')); ?>"><?php esc_html_e('Category', 'governlia'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'governlia'), 'selected'=>$cat, 'class'=>'widefat', 'name'=>$this->get_field_name('categories')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($query_string)
	{
		
		$query = new WP_Query($query_string);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
			<?php 
				global $post;
				while( $query->have_posts() ): $query->the_post(); 
				$post_thumbnail_id = get_post_thumbnail_id($post->ID);
				$post_thumbnail_url = wp_get_attachment_url($post_thumbnail_id);
			?>
            <article class="post">
                <figure class="post-thumb" style="background-image:url(<?php echo esc_url($post_thumbnail_url);?>);"><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"></a></figure>
                <div class="content">
                    <h5><a href="<?php echo esc_url(get_the_permalink(get_the_id()));?>"><?php the_title(); ?></a></h5>
                    <div class="post-info"><i class="fa fa-calendar"></i> <?php echo get_the_date();?></div>
                </div>
            </article>
            <?php endwhile; ?>
            
        <?php endif;
		wp_reset_postdata();
    }
}

//Municipal Complaints
class Governlia_Municipal_Complaints extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Governlia_Municipal_Complaints', /* Name */esc_html__('Governlia Municipal Complaints','governlia'), array( 'description' => esc_html__('Show the Municipal Complaints', 'governlia' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
			
            <!-- Contact Widget two -->
            <div class="contact-widget-two" <?php if($instance['bg_img']){ ?>style="background-image: url(<?php echo esc_url($instance['bg_img']); ?>);"<?php } ?>>
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <div class="widget-content">
                    <ul class="contact-info">
                        <?php if($instance['emergency_no']){ ?><li><a href="sos:<?php echo wp_kses_post($instance['emergency_no']); ?>"><i class="pe-7s-headphones"></i> <?php esc_html_e('Emergency', 'governlia'); ?> <?php echo wp_kses_post($instance['emergency_no']); ?></a></li><?php } ?>
                        <?php if($instance['email_address']){ ?><li><a href="mailto:<?php echo esc_attr($instance['email_address']); ?>"><i class="pe-7s-mail-open"></i> <?php echo wp_kses_post($instance['email_address']); ?></a></li><?php } ?>
                        <?php if($instance['phone_no']){ ?><li><a href="tel:<?php echo esc_attr($instance['phone_no']); ?>"><i class="pe-7s-call"></i> <?php esc_html_e('Call us', 'governlia'); ?> <?php echo wp_kses_post($instance['phone_no']); ?></a></li><?php } ?>
                    </ul>
                </div>
            </div>
            
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['bg_img'] = strip_tags($new_instance['bg_img']);
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['emergency_no'] = $new_instance['emergency_no'];
		$instance['email_address'] = $new_instance['email_address'];
		$instance['phone_no'] = $new_instance['phone_no'];
		
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$bg_img = ($instance) ? esc_attr($instance['bg_img']) : 'http://fastwpdemo.com/newwp/governlia/wp-content/uploads/2021/07/image-51.jpg';
		$title = ($instance) ? esc_attr($instance['title']) : 'Municipal Complaints';
		$emergency_no = ($instance) ? esc_attr($instance['emergency_no']) : '';
		$email_address = ($instance) ? esc_attr($instance['email_address']) : '';
		$phone_no = ($instance) ? esc_attr($instance['phone_no']) : '';
		
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('bg_img')); ?>"><?php esc_html_e('Background Image:', 'governlia'); ?></label>
            <input placeholder="<?php esc_attr_e('BG Image Url', 'governlia');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('bg_img')); ?>" name="<?php echo esc_attr($this->get_field_name('bg_img')); ?>" type="text" value="<?php echo esc_attr($bg_img); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'governlia'); ?></label>
            <input placeholder="<?php esc_attr_e('Municipal Complaints', 'governlia');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('emergency_no')); ?>"><?php esc_html_e('Emergency No:', 'governlia'); ?></label>
            <input placeholder="<?php esc_attr_e('Emergency No', 'governlia');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('emergency_no')); ?>" name="<?php echo esc_attr($this->get_field_name('emergency_no')); ?>" type="text" value="<?php echo esc_attr($emergency_no); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('email_address')); ?>"><?php esc_html_e('Email Addess:', 'governlia'); ?></label>
            <input placeholder="<?php esc_attr_e('info@example.com', 'governlia');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('email_address')); ?>" name="<?php echo esc_attr($this->get_field_name('email_address')); ?>" type="text" value="<?php echo esc_attr($email_address); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('phone_no')); ?>"><?php esc_html_e('Phone Number:', 'governlia'); ?></label>
            <input placeholder="<?php esc_attr_e('+1-800-555-44-678', 'governlia');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('phone_no')); ?>" name="<?php echo esc_attr($this->get_field_name('phone_no')); ?>" type="text" value="<?php echo esc_attr($phone_no); ?>" />
        </p> 
               
		<?php 
	}
	
}


///----Service Sidebar widgets---
//Service Sidebar
class Governlia_Service_Sidebar extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Governlia_Service_Sidebar', /* Name */esc_html__('Governlia Service Sidebar','governlia'), array( 'description' => esc_html__('Show the Service Sidebar', 'governlia' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget); ?>
		
        <!-- Instagram Widget -->
        <div class="widget_categories">
            <?php echo wp_kses_post($before_title.$title.$after_title); ?>
            <div class="widget-content">
                <ul class="categories-list">
				<?php 
                    $args = array('post_type' => 'service', 'showposts'=>$instance['number']);
                    if( $instance['cat'] ) $args['tax_query'] = array(array('taxonomy' => 'service_cat','field' => 'id','terms' => (array)$instance['cat']));
                     
                    $this->posts($args);
                ?>
                </ul>
            </div>
        </div>
        
        <?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'All Departments';
		$number = ( $instance ) ? esc_attr($instance['number']) : 6;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
		
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'governlia'); ?></label>
            <input placeholder="<?php esc_attr_e('Popular Gallery', 'governlia');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts: ', 'governlia'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'governlia'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'governlia'), 'selected'=>$cat, 'taxonomy' => 'service_cat', 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($args)
	{
		
		$query = new WP_Query($args);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
            <?php 
				while( $query->have_posts() ): $query->the_post(); 
			?>
            <li><a href="<?php echo esc_url(get_post_meta( get_the_id(), 'service_url', true ));?>"><?php if(get_post_meta(get_the_id(), 'service_icon', true )){ ?><i class="<?php echo wp_kses(str_replace( "icon ",  "", get_post_meta(get_the_id(), 'service_icon', true )), true); ?>"></i><?php } ?> <?php the_title(); ?></a></li>
            <?php endwhile; ?>
                
        <?php endif;
		wp_reset_postdata();
    }
}

//Testimonials
class Governlia_Testimonials extends WP_Widget
{
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Governlia_Testimonials', /* Name */esc_html__('Governlia Testimonials','governlia'), array( 'description' => esc_html__('Show the Testimonials', 'governlia' )) );
	}
 
	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		
		echo wp_kses_post($before_widget); ?>
		
        <!-- Instagram Widget -->
        <div class="widget_testimonial">
            <div class="row">
                <div class="theme_carousel owl-theme owl-carousel" data-options='{"loop": true, "center": false, "margin": 0, "autoheight":true, "lazyload":true, "nav": true, "dots": true, "autoplay": true, "autoplayTimeout": 6000, "smartSpeed": 1000, "responsive":{ "0" :{ "items": "1" }, "600" :{ "items" : "1" }, "992" :{ "items" : "1" } , "1200":{ "items" : "1" }, "1600":{ "items" : "1" }}}'>
					<?php 
						$args = array('post_type' => 'testimonials', 'showposts'=>$instance['number']);
						if( $instance['cat'] ) $args['tax_query'] = array(array('taxonomy' => 'testimonials_cat','field' => 'id','terms' => (array)$instance['cat']));
						$this->posts($args);
                    ?> 
                </div>
            </div>
        </div>
        
        <?php echo wp_kses_post($after_widget);
	}
 
 
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['number'] = $new_instance['number'];
		$instance['cat'] = $new_instance['cat'];
		
		return $instance;
	}
	/** @see WP_Widget::form */
	function form($instance)
	{
		$number = ( $instance ) ? esc_attr($instance['number']) : 3;
		$cat = ( $instance ) ? esc_attr($instance['cat']) : '';?>
		
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts: ', 'governlia'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('cat')); ?>"><?php esc_html_e('Category', 'governlia'); ?></label>
            <?php wp_dropdown_categories( array('show_option_all'=>esc_html__('All Categories', 'governlia'), 'selected'=>$cat, 'taxonomy' => 'testimonials_cat', 'class'=>'widefat', 'name'=>$this->get_field_name('cat')) ); ?>
        </p>
            
		<?php 
	}
	
	function posts($args)
	{
		
		$query = new WP_Query($args);
		if( $query->have_posts() ):?>
        
           	<!-- Title -->
            <?php 
				while( $query->have_posts() ): $query->the_post(); 
			?>
            <div class="col-lg-12 testimonial-block">
                <div class="inner-box">
                    <div class="content">
                        <div class="text"><?php echo esc_attr(governlia_trim(get_the_content(), 20));?></div>
                        <div class="rating">
                            <?php
							$ratting = get_post_meta( get_the_id(), 'testimonial_rating', true ); 
							for ($x = 1; $x <= 5; $x++) {
							if($x <= $ratting) echo '<span class="fa fa-star"></span>'; else echo '<span class="fa fa-star-o"></span>'; 
							}
							?>
                        </div>
                        <div class="quote"><span class="icon-quote"></span></div>
                        <div class="shape"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="92px" height="36px">
                        <path fill-rule="evenodd" fill="rgb(255, 255, 255)" d="M-0.000,-0.002 L46.000,35.999 L92.000,-0.002 L-0.000,-0.002 Z"></path>
                        </svg></div>
                    </div>
                    <div class="author">
                        <div class="thumb"><?php the_post_thumbnail('governlia_80x80'); ?></div>
                        <h4><?php the_title(); ?></h4>
                        <div class="designation"><?php echo (get_post_meta( get_the_id(), 'test_designation', true ));?></div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
                
        <?php endif;
		wp_reset_postdata();
    }
}



///----footer widgets---
//About Company
class Governlia_About_Company extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Governlia_About_Company', /* Name */esc_html__('Governlia About Company','governlia'), array( 'description' => esc_html__('Show the About Company', 'governlia' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
			<!--Footer Column-->
            <div class="about-widget">
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <div class="text"><?php echo wp_kses_post($instance['content']); ?></div>
                
                <?php if( $instance['show'] ): ?>
                <?php echo wp_kses_post(governlia_get_social_icon()); ?>
                <?php endif; ?>
                
            </div>
            
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;

		$instance['title'] = $new_instance['title'];
		$instance['content'] = $new_instance['content'];
		$instance['show'] = $new_instance['show'];
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		$title = ($instance) ? esc_attr($instance['title']) : 'About Us';
		$content = ($instance) ? esc_attr($instance['content']) : '';
		$show = ($instance) ? esc_attr($instance['show']) : '';
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'governlia'); ?></label>
            <input placeholder="<?php esc_attr_e('About us', 'governlia');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php esc_html_e('Content:', 'governlia'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>" ><?php echo wp_kses_post($content); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('show')); ?>"><?php esc_html_e('Show Social Icons:', 'governlia'); ?></label>
			<?php $selected = ( $show ) ? ' checked="checked"' : ''; ?>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('show')); ?>"<?php echo esc_attr($selected); ?> name="<?php echo esc_attr($this->get_field_name('show')); ?>" type="checkbox" value="true" />
        </p>              
                
		<?php 
	}
	
}

//Contact Info
class Governlia_Contact_Info extends WP_Widget
{
	
	/** constructor */
	function __construct()
	{
		parent::__construct( /* Base ID */'Governlia_Contact_Info', /* Name */esc_html__('Governlia Contact Info','governlia'), array( 'description' => esc_html__('Show the Contact Info', 'governlia' )) );
	}

	/** @see WP_Widget::widget */
	function widget($args, $instance)
	{
		extract( $args );
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		echo wp_kses_post($before_widget);?>
      		
			<div class="contact-widget">
                <?php echo wp_kses_post($before_title.$title.$after_title); ?>
                <div class="widget-content">
                    <ul class="contact-info">
                        <?php if($instance['address']){ ?>
                        <li>
                            <div class="icon"><i class="icons pe-7s-map-2"></i></div>
                            <div class="text"><?php echo wp_kses_post($instance['address']); ?></div>
                        </li>
                        <?php } ?>
                        <?php if($instance['phone_no']){ ?>
                        <li>
                            <div class="icon"><i class="icons pe-7s-phone"></i></div>
                            <div class="text">
                                <strong><?php esc_attr_e('Phone No.', 'governlia'); ?></strong>
                                <a href="tel:<?php echo esc_attr($instance['phone_no']); ?>"><?php echo wp_kses_post($instance['phone_no']); ?></a>
                            </div>
                        </li>
                        <?php } ?>
                        <?php if($instance['email_address']){ ?>
                        <li>
                            <div class="icon"><i class="icons pe-7s-mail"></i></div>
                            <div class="text">
                                <strong><?php esc_attr_e('Email', 'governlia'); ?></strong>
                                <a href="mailto:<?php echo esc_attr($instance['email_address']); ?>"><?php echo wp_kses_post($instance['email_address']); ?></a>
                            </div>
                        </li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
                        
        <?php
		
		echo wp_kses_post($after_widget);
	}
	
	
	/** @see WP_Widget::update */
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['address'] = $new_instance['address'];
		$instance['phone_no'] = $new_instance['phone_no'];
		$instance['email_address'] = $new_instance['email_address'];
		
		
		return $instance;
	}

	/** @see WP_Widget::form */
	function form($instance)
	{
		
		$title = ($instance) ? esc_attr($instance['title']) : 'Contact Us';
		$address = ($instance) ? esc_attr($instance['address']) : '';
		$phone_no = ($instance) ? esc_attr($instance['phone_no']) : '';
		$email_address = ($instance) ? esc_attr($instance['email_address']) : '';
		?>
        
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Enter Title:', 'governlia'); ?></label>
            <input placeholder="<?php esc_attr_e('Contact Us', 'governlia');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('address')); ?>"><?php esc_html_e('Address:', 'governlia'); ?></label>
            <textarea class="widefat" id="<?php echo esc_attr($this->get_field_id('address')); ?>" name="<?php echo esc_attr($this->get_field_name('address')); ?>" ><?php echo wp_kses_post($address); ?></textarea>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('phone_no')); ?>"><?php esc_html_e('Phone Number:', 'governlia'); ?></label>
            <input placeholder="<?php esc_attr_e('+1-800-555-44-678', 'governlia');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('phone_no')); ?>" name="<?php echo esc_attr($this->get_field_name('phone_no')); ?>" type="text" value="<?php echo esc_attr($phone_no); ?>" />
        </p> 
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('email_address')); ?>"><?php esc_html_e('Email Addess:', 'governlia'); ?></label>
            <input placeholder="<?php esc_attr_e('info@example.com', 'governlia');?>" class="widefat" id="<?php echo esc_attr($this->get_field_id('email_address')); ?>" name="<?php echo esc_attr($this->get_field_name('email_address')); ?>" type="text" value="<?php echo esc_attr($email_address); ?>" />
        </p>
               
                
		<?php 
	}
	
}
