<?php

namespace GOVERNLIAPLUGIN\Inc;


use GOVERNLIAPLUGIN\Inc\Abstracts\Taxonomy;


class Taxonomies extends Taxonomy {


	public static function init() {

		$labels = array(
			'name'              => _x( 'Project Category', 'wpgovernlia' ),
			'singular_name'     => _x( 'Project Category', 'wpgovernlia' ),
			'search_items'      => __( 'Search Category', 'wpgovernlia' ),
			'all_items'         => __( 'All Categories', 'wpgovernlia' ),
			'parent_item'       => __( 'Parent Category', 'wpgovernlia' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpgovernlia' ),
			'edit_item'         => __( 'Edit Category', 'wpgovernlia' ),
			'update_item'       => __( 'Update Category', 'wpgovernlia' ),
			'add_new_item'      => __( 'Add New Category', 'wpgovernlia' ),
			'new_item_name'     => __( 'New Category Name', 'wpgovernlia' ),
			'menu_name'         => __( 'Project Category', 'wpgovernlia' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'project_cat' ),
		);

		register_taxonomy( 'project_cat', 'project', $args );
		
		//Services Taxonomy Start
		$labels = array(
			'name'              => _x( 'Service Category', 'wpgovernlia' ),
			'singular_name'     => _x( 'Service Category', 'wpgovernlia' ),
			'search_items'      => __( 'Search Category', 'wpgovernlia' ),
			'all_items'         => __( 'All Categories', 'wpgovernlia' ),
			'parent_item'       => __( 'Parent Category', 'wpgovernlia' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpgovernlia' ),
			'edit_item'         => __( 'Edit Category', 'wpgovernlia' ),
			'update_item'       => __( 'Update Category', 'wpgovernlia' ),
			'add_new_item'      => __( 'Add New Category', 'wpgovernlia' ),
			'new_item_name'     => __( 'New Category Name', 'wpgovernlia' ),
			'menu_name'         => __( 'Service Category', 'wpgovernlia' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'service_cat' ),
		);


		register_taxonomy( 'service_cat', 'service', $args );
		
		//Testimonials Taxonomy Start
		$labels = array(
			'name'              => _x( 'Testimonials Category', 'wpgovernlia' ),
			'singular_name'     => _x( 'Testimonials Category', 'wpgovernlia' ),
			'search_items'      => __( 'Search Category', 'wpgovernlia' ),
			'all_items'         => __( 'All Categories', 'wpgovernlia' ),
			'parent_item'       => __( 'Parent Category', 'wpgovernlia' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpgovernlia' ),
			'edit_item'         => __( 'Edit Category', 'wpgovernlia' ),
			'update_item'       => __( 'Update Category', 'wpgovernlia' ),
			'add_new_item'      => __( 'Add New Category', 'wpgovernlia' ),
			'new_item_name'     => __( 'New Category Name', 'wpgovernlia' ),
			'menu_name'         => __( 'Testimonials Category', 'wpgovernlia' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'testimonials_cat' ),
		);


		register_taxonomy( 'testimonials_cat', 'testimonials', $args );
		
		
		//Team Taxonomy Start
		$labels = array(
			'name'              => _x( 'Team Category', 'wpgovernlia' ),
			'singular_name'     => _x( 'Team Category', 'wpgovernlia' ),
			'search_items'      => __( 'Search Category', 'wpgovernlia' ),
			'all_items'         => __( 'All Categories', 'wpgovernlia' ),
			'parent_item'       => __( 'Parent Category', 'wpgovernlia' ),
			'parent_item_colon' => __( 'Parent Category:', 'wpgovernlia' ),
			'edit_item'         => __( 'Edit Category', 'wpgovernlia' ),
			'update_item'       => __( 'Update Category', 'wpgovernlia' ),
			'add_new_item'      => __( 'Add New Category', 'wpgovernlia' ),
			'new_item_name'     => __( 'New Category Name', 'wpgovernlia' ),
			'menu_name'         => __( 'Team Category', 'wpgovernlia' ),
		);
		$args   = array(
			'hierarchical'       => true,
			'labels'             => $labels,
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'public'             => true,
			'publicly_queryable' => true,
			'rewrite'            => array( 'slug' => 'team_cat' ),
		);


		register_taxonomy( 'team_cat', 'team', $args );
		
		
	}
	
}
